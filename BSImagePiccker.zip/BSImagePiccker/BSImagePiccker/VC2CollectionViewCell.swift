//
//  VC2CollectionViewCell.swift
//  BSImagePiccker
//
//  Created by Mac on 9/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class VC2CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var Vc2imgView: UIImageView!
    
}

//
//  cusCollectionViewCell.swift
//  BSImagePiccker
//
//  Created by Mac on 9/6/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class cusCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
}

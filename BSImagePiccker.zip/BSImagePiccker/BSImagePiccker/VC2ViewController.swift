//
//  VC2ViewController.swift
//  BSImagePiccker
//
//  Created by Mac on 9/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class VC2ViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    
    @IBOutlet weak var collView2: UICollectionView!
    
    var mainArry:ViewController = ViewController()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        collView2.delegate = self
        collView2.dataSource = self
       self.collView2.reloadData()
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    
        
        return  mainArry.photoArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell
    {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "VC2CollectionViewCell", for: indexPath)as! VC2CollectionViewCell
        
        cell.Vc2imgView.image = mainArry.photoArray[indexPath.row] as? UIImage
        self.collView2.reloadData()
        return cell
    }
    


}

//
//  cusSecCollectionViewCell.swift
//  BSImagePiccker
//
//  Created by Mac on 9/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class cusSecCollectionViewCell: UICollectionViewCell {
    
}

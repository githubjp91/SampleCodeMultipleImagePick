//
//  ViewController.swift
//  BSImagePiccker
//
//  Created by agile-13 on 06/09/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit
import Photos
import BSImagePicker

class ViewController: UIViewController {
    
    @IBOutlet weak var collView: UICollectionView!
    
 var selectAssets  = [PHAsset]()
    var photoArray = [UIImage]()
  
    var newAry:[Int] = []
    
    @IBOutlet weak var imgView: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }

    @IBAction func OpenImageAction(_ sender: UIButton)
    {
    let vc = BSImagePickerViewController()
        self.bs_presentImagePickerController(vc, animated: true, select: { (asset:PHAsset)-> Void in
            
        }, deselect: { (asset:PHAsset)-> Void in
            
        }, cancel: { (assets:[PHAsset])-> Void in
            
        }, finish: { (assets:[PHAsset])-> Void in
            for i in 0..<assets.count
            {
                self.selectAssets.append(assets[i])
            }
            self.convertToImage()
            
        }, completion: nil)
        
    }
    
    func convertToImage()
    {
        if selectAssets.count != 0
        {
            for i in 0..<selectAssets.count
            {
                let manager = PHImageManager.default()
                let option = PHImageRequestOptions()
                var thumbnail = UIImage()
                option.isSynchronous = true
                manager.requestImage(for: selectAssets[i], targetSize: CGSize(width:200 , height:200), contentMode: .aspectFill, options: option, resultHandler: { (result, info)-> Void in
                    
                    thumbnail = result!
                })
                let data  = UIImageJPEGRepresentation(thumbnail, 0.7)
                let newImage = UIImage(data: data!)
                
                self.photoArray.append(newImage! as UIImage)
                
            }
            self.imgView.animationImages = self.photoArray
          // self.imgView.animationDuration = 5.0
           // self.imgView.startAnimating()
            self.collView.reloadData()
            
        }
        print("Complete photo array\(self.photoArray)")
    }
}

extension ViewController: UICollectionViewDelegate, UICollectionViewDataSource

{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int
    {
        return photoArray.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cusCollectionViewCell", for: indexPath)as! cusCollectionViewCell
        
        cell.cellImage.image = photoArray[indexPath.row]
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath)
    {
      let selectIndex = indexPath.row
        
        print(selectIndex)
        
        
        var vc = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "VC2ViewController")as! VC2ViewController
        
        navigationController?.pushViewController(vc, animated: true)
      
}
}

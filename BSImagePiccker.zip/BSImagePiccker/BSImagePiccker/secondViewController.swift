//
//  secondViewController.swift
//  BSImagePiccker
//
//  Created by Mac on 9/10/18.
//  Copyright © 2018 Agile. All rights reserved.
//

import UIKit

class secondViewController: UIViewController , UICollectionViewDataSource, UICollectionViewDelegate {
    

    
    override func viewDidLoad() {
        super.viewDidLoad()

        
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        <#code#>
    }
    
    

}
